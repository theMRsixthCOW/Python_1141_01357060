import pandas as pd
import os
import glob

print("=== Debug Script ===")
print()

# Check current directory
print(f"Current directory: {os.getcwd()}")
print()

# Check if file.csv exists
if os.path.exists('file.csv'):
    print("✓ file.csv found")
    try:
        with open('file.csv', 'r', encoding='utf-8') as f:
            lines = f.readlines()
        print(f"✓ file.csv contains {len(lines)} lines")
        print("First 5 lines:")
        for i, line in enumerate(lines[:5]):
            print(f"  {i+1}. {line.strip()}")
    except Exception as e:
        print(f"✗ Error reading file.csv: {e}")
else:
    print("✗ file.csv NOT found")

print()

# Check for .ods files in directory
ods_files = glob.glob('*.ods')
print(f"Found {len(ods_files)} .ods files in current directory")
if ods_files:
    print("First 5 .ods files:")
    for i, f in enumerate(ods_files[:5]):
        print(f"  {i+1}. {f}")
else:
    print("✗ No .ods files found in current directory")

print()

# Check pandas and odf engine
try:
    import pandas as pd
    print(f"✓ pandas version: {pd.__version__}")
except:
    print("✗ pandas not installed")

try:
    import odf
    print("✓ odfpy installed")
except:
    print("✗ odfpy not installed - run: pip install odfpy")

print()

# Try to read first .ods file
if ods_files:
    print(f"Attempting to read: {ods_files[0]}")
    try:
        df = pd.read_excel(ods_files[0], engine='odf')
        print(f"✓ Successfully read file")
        print(f"  Rows: {len(df)}")
        print(f"  Columns: {list(df.columns)}")
        print()
        print("First few rows:")
        print(df.head())
    except Exception as e:
        print(f"✗ Error reading file: {e}")
        print("Try installing: pip install odfpy")

print()
print("=== End Debug ===")